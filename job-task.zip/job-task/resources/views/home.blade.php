<x-base>

<x-slot name="name">
    Kamil
</x-slot>

<x-slot name="content">


<h1>Home page</h1>

@if ($name == "Kamil Rutkowski")
    <h1>Hello Admin Blade </h1>
@else   
    <h1>Hello  {{ $name }} </h1>
@endif
</x-slot>

</x-base>