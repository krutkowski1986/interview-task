@if (session('success'))
<p style="color: green">{{ $slot }}</p>
@endif