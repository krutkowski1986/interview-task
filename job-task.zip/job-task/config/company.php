<?php

declare(strict_types=1);

return [
    'name' => 'TEST NAME MY COMPANY',
    'street' => 'New York street 13',
    'city' => 'New York',
    'zip' => 'WYW-123',
    'phone' => '+22 513 258 1698',
    'email' => 'random@example.com',
];
