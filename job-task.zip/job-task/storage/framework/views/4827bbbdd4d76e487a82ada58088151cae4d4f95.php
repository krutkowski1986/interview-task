<?php if(session('success')): ?>
<p style="color: green"><?php echo e($slot); ?></p>
<?php endif; ?><?php /**PATH /var/www/resources/views/components/alert-success.blade.php ENDPATH**/ ?>