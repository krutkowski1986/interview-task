<?php return array (
  'invoices-table-view' => 'App\\Http\\Livewire\\InvoicesTableView',
);